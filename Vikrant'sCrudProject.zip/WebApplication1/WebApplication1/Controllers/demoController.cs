﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;
using WebApplication1.Models;
namespace WebApplication1.Controllers
{
    public class demoController : Controller
    {
        demoEntities dm = new demoEntities();
        //
        // GET: /demo/
        public ActionResult Index()
        {
            return View(dm.TblCategories.ToList());
          //var list= dm.spshowdata();
          //  var modeldata = list.Select(a => new CategoryModel()
          //  {
          //      CategoryName = a.CategoryName,
          //      ProductName = a.CategoryName
          //  }).ToList();
          //return View(modeldata);
            //var td = from s in dm.TblCategories
            //         join r in dm.TblProducts on s.CategoryId equals r.ProductId
                     
            //         select s;
            //var tables = new CategoryModel
            //{
            //    TblCategory = dm.TblCategories.ToList(),
            //    TblProduct = dm.TblProducts.ToList(),
                
            //};
            //return View(list);  
        }
        [HttpGet]
        public ActionResult add()
        {
            return View();
        }
        [HttpPost]
        public ActionResult add(CategoryModel m)
        {
            dm.spInsert(m.CategoryName);
            ViewData["success"] = "Action completed successfully";
            return View(m);
          //  ViewBag.result = "Record Inserted Successfully!";
            
        }
        public ActionResult addproduct()
        {
            return View();
        }
        [HttpPost]
        public ActionResult addproduct(CategoryModel m)
        {
            dm.spInsertproduct(m.ProductName);
            ViewData["success"] = "product insert successfully";
            return View(m);
            //  ViewBag.result = "Record Inserted Successfully!";

        }
        [HttpGet]
        public ActionResult Edit(int id)
        {
          TblCategory employeedetail = dm.TblCategories.Find(id);

          if (employeedetail == null)

          {

            return HttpNotFound();

             }
            return View(employeedetail);
        }
        [HttpPost]
        public ActionResult Edit(TblCategory employeedetail)
        {

            if (ModelState.IsValid)
            {

                dm.Entry(employeedetail).State = EntityState.Modified;

                dm.SaveChanges();

                return RedirectToAction("Index");

            }

            return View(employeedetail);

        }

        public ActionResult Delete(int id = 0)
        {

            TblCategory employeedetail = dm.TblCategories.Find(id);

            if (employeedetail == null)
            {

                return HttpNotFound();

            }

            return View(employeedetail);

        }

        //

        // POST: /Employee/Delete/5

        [HttpPost, ActionName("Delete")]

        public ActionResult DeleteConfirmed(int id)
        {

            TblCategory employeedetail = dm.TblCategories.Find(id);

            dm.TblCategories.Remove(employeedetail);

            dm.SaveChanges();

            return RedirectToAction("Index");

        }

	}
}