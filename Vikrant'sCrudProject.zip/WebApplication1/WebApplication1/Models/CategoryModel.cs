﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;
using WebApplication1.Models;
namespace WebApplication1.Models
{
    public class CategoryModel
    {
        public IEnumerable<TblCategory> TblCategory { get; set; }
        public IEnumerable<TblProduct> TblProduct { get; set; }  
        public int CategoryId { get; set; }
        [Required]
        public string CategoryName { get; set; }
        public int ProductId { get; set; }
        [Required]
        public string ProductName { get; set; }
       
    }
}